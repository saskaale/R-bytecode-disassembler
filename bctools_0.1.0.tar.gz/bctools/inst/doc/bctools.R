## ------------------------------------------------------------------------

library(compiler)
library(bctools)

f <- function(x){
    sum <- 0
    while(x > 0){
        sum <- sum + x
    }
    sum
}

bytecode <- compiler::cmpfun(f);

print(compiler::disassemble(bytecode));



