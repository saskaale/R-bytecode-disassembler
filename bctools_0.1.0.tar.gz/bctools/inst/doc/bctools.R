## ------------------------------------------------------------------------

library(compiler)
library(bctools)

x <- 2

bytecode <- compiler::compile(quote(x+2));

print(compiler::disassemble(bytecode));


## ------------------------------------------------------------------------

library(compiler)
library(bctools)

f <- function(x){
    sum <- 0
    while(x > 0){
        sum <- sum + x
    }
    sum
}

bytecode <- compiler::cmpfun(f);

print(compiler::disassemble(bytecode));


## ------------------------------------------------------------------------

library(compiler)
library(bctools)

f <- function(x){
    sum <- 0
    while(x > 0){
        sum <- sum + x
    }
    sum
}

bytecode <- compiler::cmpfun(f);

print(compiler::disassemble(bytecode), verbose=1);


## ------------------------------------------------------------------------

library(compiler)
library(bctools)

f <- function(x){
    sum <- 0
    while(x > 0){
        sum <- sum + x
    }
    sum
}

bytecode <- compiler::cmpfun(f);

print(compiler::disassemble(bytecode), verbose=2);



