## ---- fig.show='hold'----------------------------------------------------
plot(1:10)
plot(10:1)

## ------------------------------------------------------------------------

library(compiler)
library(bctools)

f <- function(x){ x+2 }

cmp <- compiler::cmpfun(f);
print(compiler::disassemble(cmp));


