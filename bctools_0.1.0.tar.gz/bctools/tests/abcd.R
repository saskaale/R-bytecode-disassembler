a <- 1
b <- 2
d <- 5
c <- function(a,b=d) { a*2+b*4+a+d }

print( a*2+b*d+c(a)+a+d,a+d )
print(c(a,b)+d)