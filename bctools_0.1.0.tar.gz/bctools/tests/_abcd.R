a <- 1
b <- 2
d <- 5
c <- function(a,b=d) { a*2+b*4+a+d }

print( a+c(a),a )
#print(c(a,b)+d)